<?php
//define("SERVER", "ap-cdbr-azure-southeast-a.cloudapp.net");
//define("USERNAME", "b67f1af0f65368");
//define("PASSWORD", "73ad19be");
//define("DBNAME", "scrum");
//

define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DBNAME", "scrum");
?>