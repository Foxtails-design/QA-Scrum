#### Web Mock Up (Senior Project)
##### Welcome to Scrum Board
##### Issue and Progress tracking designed for Scrum team

