<?php
date_default_timezone_set("Asia/Bangkok");
if (isset($_GET['id'])) {
    include_once "C:/xampp/htdocs/Scrum/configs/config.php";
    include_once "C:/xampp/htdocs/Scrum/classes/ManageUserStory.php";


    $now = date('Y-m-d', strtotime('now'));

    $con = new ManageUserStory();
    $result = $con->updateStoryExpire($now);
    header("location: C:/xampp/htdocs/Scrum/action_sprint.php");
}
?>